﻿using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Text;



class SimpleTcpSocketClient
{
    public static void Main()
    {
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9050);
        try
        {
            socket.Connect(remoteEP);
        }
        catch (SocketException e)
        {
            Console.WriteLine("Unable to connect to server. ");
            Console.WriteLine(e);
            return;
        }

        byte[] data = new byte[1024];
        int dataSize = socket.Receive(data);
        Console.WriteLine(Encoding.ASCII.GetString(data, 0, dataSize));
        String input = null;
        while (true)
        {
            Console.Write("Enter Message for Server <Enter to Stop>: ");
            input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
                break;

            socket.Send(Encoding.ASCII.GetBytes(input));

            dataSize = socket.Receive(data);
            Console.WriteLine("Server response: " + Encoding.ASCII.GetString(data, 0, dataSize));
        }

        Console.WriteLine("Disconnecting from Server..");
        socket.Shutdown(SocketShutdown.Both);
        socket.Close();

    }

    public void RegisterOrLogin()
    {
        string userName = m_Usuario_Conectado.text;
        string password = m_Password.text;

        // Lógica para registrar o autenticar al usuario
    }

    public void SendInvite()
    {
        string invite = m_Invite.text;

        // Lógica para invitar a los jugadores
    }

    public void SendChatMessage()
    {
        string chatMessage = m_Mensaje_Chat.text;

        // Lógica para enviar el mensaje de chat
    }

    public void QueryPlayedGames()
    {
        string player = m_Personas_Jugadas.text;
        string date = m_Fecha.text;

        // Lógica para consultar las partidas jugadas con el jugador y en la fecha indicada
    }


    public void Log_In()        //Funcion del boton login
    {
        if (string.IsNullOrEmpty(m_Usuario_Conectado.text))
        {
            if (!string.IsNullOrEmpty(username.text) && !string.IsNullOrEmpty(m_Password.text))
            {
                string NOMBRE = m_UserName.text;
                string CONTRASEÑA = m_Password.text;
                byte[] Mensaje_Cliente = Encoding.ASCII.GetBytes("1/" + NOMBRE + "/" + CONTRASEÑA);
                server.Send(Mensaje_Cliente);
            }
            else { m_Prefab.text = "Introduzca sus datos para empezar"; }

        }
        else
        {
            m_Prefab.text = "Ya hay una sesión iniciada, si quiere cambiar de sesión, desconéctese de la actual.";
        }
    }
}
